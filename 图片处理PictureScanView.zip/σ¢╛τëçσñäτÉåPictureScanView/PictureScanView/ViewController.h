//
//  ViewController.h
//  PictureScanView
//
//  Created by xhliang on 15/12/30.
//  Copyright © 2015年 xhliang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

